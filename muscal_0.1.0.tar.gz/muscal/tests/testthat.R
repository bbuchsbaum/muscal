library(testthat)
library(muscal)

test_check("muscal")

